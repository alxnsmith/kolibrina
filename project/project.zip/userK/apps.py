from django.apps import AppConfig


class UserkConfig(AppConfig):
    name = 'userK'
