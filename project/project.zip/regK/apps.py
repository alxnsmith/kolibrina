from django.apps import AppConfig


class RegkConfig(AppConfig):
    name = 'regK'
