from django.apps import AppConfig


class LoginkConfig(AppConfig):
    name = 'authK'
