from django.apps import AppConfig


class AccountconfirmationConfig(AppConfig):
    name = 'accountConfirmation'
